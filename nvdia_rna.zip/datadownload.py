import GEOparse

gse = GEOparse.get_GEO("GSE81608", destdir="./data")

# GSE 레벨의 supplementary files 확인
print("=== GSE Level Supplementary Files ===")
if hasattr(gse, 'download_supplementary_files'):
    supp_files = gse.download_supplementary_files(directory="./data/GSE81608_suppl")
    print(supp_files)
else:
    # 또는 직접 확인
    print(gse.metadata.get('supplementary_file', 'No files'))