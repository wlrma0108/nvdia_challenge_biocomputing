# test_load.py 새로 만들어서 테스트
import pandas as pd
import gzip

# GSE86468 테스트
print("Testing GSE86468...")
try:
    with gzip.open('suppl_data/GSE86468/GSE86468_GEO.bulk.islet.processed.data.RSEM.raw.expected.counts.csv.gz', 'rt') as f:
        # 첫 5줄만 읽어보기
        for i, line in enumerate(f):
            if i < 5:
                print(f"Line {i}: {line[:100]}")  # 앞 100자만
            else:
                break
    
    # 전체 로드
    df = pd.read_csv('suppl_data/GSE86468/GSE86468_GEO.bulk.islet.processed.data.RSEM.raw.expected.counts.csv.gz',
                     compression='gzip', index_col=0)
    print(f"Shape: {df.shape}")
    print(f"Columns: {df.columns.tolist()[:5]}")  # 처음 5개 컬럼
    print(f"Index: {df.index.tolist()[:5]}")  # 처음 5개 유전자
except Exception as e:
    print(f"Error: {e}")

print("\n" + "="*50 + "\n")

# GSE86469 테스트
print("Testing GSE86469...")
try:
    with gzip.open('suppl_data/GSE86469/GSE86469_GEO.islet.single.cell.processed.data.RSEM.raw.expected.counts.csv.gz', 'rt') as f:
        for i, line in enumerate(f):
            if i < 5:
                print(f"Line {i}: {line[:100]}")
            else:
                break
    
    df = pd.read_csv('suppl_data/GSE86469/GSE86469_GEO.islet.single.cell.processed.data.RSEM.raw.expected.counts.csv.gz',
                     compression='gzip', index_col=0)
    print(f"Shape: {df.shape}")
    print(f"Columns: {df.columns.tolist()[:5]}")
    print(f"Index: {df.index.tolist()[:5]}")
except Exception as e:
    print(f"Error: {e}")