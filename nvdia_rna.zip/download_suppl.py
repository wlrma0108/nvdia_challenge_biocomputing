import os
import urllib.request
from pathlib import Path

def download_geo_supplementary(geo_id, output_dir='./suppl_data'):
    """GEO supplementary files 다운로드"""
    
    # 출력 디렉토리 생성
    Path(output_dir).mkdir(exist_ok=True)
    geo_dir = Path(output_dir) / geo_id
    geo_dir.mkdir(exist_ok=True)
    
    # GEO FTP 경로 구성
    # 예: GSE81608 -> GSE81nnn/GSE81608/suppl/
    geo_num = geo_id.replace('GSE', '')
    geo_series = f"GSE{geo_num[:-3]}nnn"
    
    ftp_base = f"ftp://ftp.ncbi.nlm.nih.gov/geo/series/{geo_series}/{geo_id}/suppl/"
    
    print(f"🔍 Checking {geo_id}...")
    print(f"   FTP: {ftp_base}")
    
    try:
        # FTP 디렉토리 내용 확인
        from ftplib import FTP
        ftp = FTP('ftp.ncbi.nlm.nih.gov')
        ftp.login()
        
        ftp_path = f"/geo/series/{geo_series}/{geo_id}/suppl/"
        ftp.cwd(ftp_path)
        
        files = []
        ftp.dir(files.append)
        
        if not files:
            print(f"   ⚠️  No supplementary files found")
            return False
        
        print(f"   📦 Found {len(files)} file(s)")
        
        # 파일 다운로드
        for file_info in files:
            filename = file_info.split()[-1]
            
            # 큰 파일들만 다운 (보통 count matrix)
            if any(keyword in filename.lower() for keyword in ['count', 'matrix', 'expr', 'data']):
                local_path = geo_dir / filename
                
                if local_path.exists():
                    print(f"   ⏭️  Skipping {filename} (already exists)")
                    continue
                
                print(f"   ⬇️  Downloading {filename}...")
                
                # FTP로 다운로드
                with open(local_path, 'wb') as f:
                    ftp.retrbinary(f'RETR {filename}', f.write)
                
                print(f"   ✅ Saved to {local_path}")
        
        ftp.quit()
        return True
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False

# 사용법
if __name__ == '__main__':
    geo_ids = ['GSE164416', 'GSE81608', 'GSE86468', 'GSE86469']
    
    print("="*80)
    print("📥 GEO Supplementary Files Downloader")
    print("="*80)
    
    for geo_id in geo_ids:
        download_geo_supplementary(geo_id)
        print()
    
    print("="*80)
    print("✅ Download complete!")
    print("="*80)