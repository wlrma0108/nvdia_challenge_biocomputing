import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, roc_auc_score, roc_curve
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.feature_selection import VarianceThreshold
import xgboost as xgb
from pathlib import Path
import gzip
import os
import warnings
from scipy import stats
from itertools import combinations
warnings.filterwarnings('ignore')

class DiabetesClassifier:
    def __init__(self, expression_data, metadata, output_dir='./ml_results'):
        self.expr = expression_data
        self.metadata = metadata
        self.output_dir = output_dir
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
        print("="*80)
        print("🧬 DIABETES CLASSIFICATION WITH MACHINE LEARNING")
        print("="*80)
        print(f"\n📊 Loaded data:")
        print(f"   Expression: {self.expr.shape[0]} genes × {self.expr.shape[1]} samples")
        print(f"   Metadata: {self.metadata.shape[0]} samples")
    
    def differential_expression_selection(self, n_top_genes=1000):
        print(f"\n🧬 DIFFERENTIAL EXPRESSION FEATURE SELECTION")
        print("-"*80)
        
        if 'diabetes_status' not in self.metadata.columns:
            print("   ⚠️  No diabetes_status found, skipping DE selection")
            return None
        
        # ✅ self.expr은 genes × samples 형태
        # 컬럼이 샘플 ID들
        expr_genes = self.expr  # Transpose 안 함!
        
        unique_groups = self.metadata['diabetes_status'].unique()
        print(f"   Groups: {unique_groups}")
        
        # ✅ 디버깅 정보
        print(f"   Expression columns (samples): {expr_genes.columns.tolist()[:5]}")
        print(f"   Metadata index (samples): {self.metadata.index.tolist()[:5]}")
        
        de_scores = []
        
        for group1, group2 in combinations(unique_groups, 2):
            print(f"   Comparing {group1} vs {group2}...")
            
            # ✅ 샘플 ID 가져오기
            samples1 = self.metadata[self.metadata['diabetes_status'] == group1].index.tolist()
            samples2 = self.metadata[self.metadata['diabetes_status'] == group2].index.tolist()
            
            # ✅ 실제 expression에 있는 샘플만 사용
            samples1 = [s for s in samples1 if s in expr_genes.columns]
            samples2 = [s for s in samples2 if s in expr_genes.columns]
            
            print(f"      Group1 ({group1}): {len(samples1)} samples")
            print(f"      Group2 ({group2}): {len(samples2)} samples")
            
            if len(samples1) < 2 or len(samples2) < 2:
                print(f"      ⚠️  Not enough samples, skipping")
                continue
            
            for gene in expr_genes.index:
                try:
                    # ✅ 각 그룹의 값 추출
                    vals1 = expr_genes.loc[gene, samples1].values
                    vals2 = expr_genes.loc[gene, samples2].values
                    
                    if vals1.std() == 0 and vals2.std() == 0:
                        continue
                    
                    t_stat, p_val = stats.ttest_ind(vals1, vals2)
                    
                    mean1 = vals1.mean()
                    mean2 = vals2.mean()
                    
                    if mean2 == 0:
                        log2fc = 0
                    else:
                        log2fc = np.log2((mean1 + 1) / (mean2 + 1))
                    
                    de_scores.append({
                        'gene': gene,
                        'comparison': f'{group1}_vs_{group2}',
                        'log2fc': log2fc,
                        'pvalue': p_val,
                        'abs_log2fc': abs(log2fc),
                        'neg_log_pval': -np.log10(p_val) if p_val > 0 else 0
                    })
                except Exception as e:
                    continue
        
        if not de_scores:
            print("   ⚠️  No DE results, using variance selection")
            return None
        
        de_df = pd.DataFrame(de_scores)
        
        de_df['de_score'] = de_df['abs_log2fc'] * de_df['neg_log_pval']
        
        gene_max_scores = de_df.groupby('gene')['de_score'].max().sort_values(ascending=False)
        
        top_de_genes = gene_max_scores.head(n_top_genes).index.tolist()
        
        print(f"\n   ✅ Selected top {len(top_de_genes)} DE genes")
        print(f"   DE score range: [{gene_max_scores.iloc[-1]:.3f}, {gene_max_scores.iloc[0]:.3f}]")
        
        print(f"\n   Top 10 DE genes:")
        for i, (gene, score) in enumerate(gene_max_scores.head(10).items(), 1):
            print(f"      {i}. {gene}: {score:.3f}")
        
        gene_max_scores.to_csv(f'{self.output_dir}/de_gene_scores.csv', header=['DE_score'])
        
        return top_de_genes
    
    def preprocess_data_with_de(self, n_de_genes=1000, n_var_genes=4000, exclude_classes=['T3cD']):
        print(f"\n🔧 PREPROCESSING WITH DE SELECTION")
        print("-"*80)
        
        diabetes_col = 'diabetes_label'
        
        if diabetes_col not in self.metadata.columns:
            raise ValueError(f"No {diabetes_col} column found in metadata")
        
        print(f"Original class distribution:")
        print(self.metadata[diabetes_col].value_counts())
        
        print(f"\n🔄 Matching sample IDs...")
        
        if 'title' in self.metadata.columns:
            import re
            
            def extract_sample_id(title):
                match = re.search(r'(DP\d+)', str(title))
                return match.group(1) if match else None
            
            self.metadata['sample_id_extracted'] = self.metadata['title'].apply(extract_sample_id)
            valid_mask = self.metadata['sample_id_extracted'].notna()
            self.metadata = self.metadata[valid_mask]
            self.metadata = self.metadata.set_index('sample_id_extracted', drop=False)
        
        # ✅ 먼저 common samples 찾기
        common_samples = list(set(self.expr.columns) & set(self.metadata.index))
        
        if len(common_samples) == 0:
            raise ValueError("No matching samples")
        
        self.expr = self.expr[common_samples]
        self.metadata = self.metadata.loc[common_samples]
        
        print(f"\n✅ Matched {len(common_samples)} samples")
        print(self.metadata[diabetes_col].value_counts())
        
        # ✅ 그 다음 필터링 (T3cD 제거)
        mask = ~self.metadata[diabetes_col].isin(exclude_classes)
        self.metadata = self.metadata[mask]
        
        # ✅ Expression도 같이 필터링
        filtered_samples = self.metadata.index.tolist()
        self.expr = self.expr[filtered_samples]
        
        print(f"\n✅ After filtering (excluded: {exclude_classes}):")
        print(self.metadata[diabetes_col].value_counts())
        print(f"   Total samples: {len(filtered_samples)}")
        
        self.metadata['diabetes_status'] = self.metadata[diabetes_col]
        
        # ✅ 이제 DE selection (필터링된 데이터로)
        print(f"\n📊 Step 1: DE-based feature selection ({n_de_genes} genes)")
        de_genes = self.differential_expression_selection(n_top_genes=n_de_genes)
        
        print(f"\n📊 Step 2: Variance-based selection ({n_var_genes} genes)")
        
        if de_genes is not None:
            remaining_genes = [g for g in self.expr.index if g not in de_genes]
            expr_remaining = self.expr.loc[remaining_genes]
        else:
            expr_remaining = self.expr
            de_genes = []
        
        gene_vars = expr_remaining.var(axis=1).sort_values(ascending=False)
        n_var_to_select = min(n_var_genes, len(gene_vars))
        var_genes = gene_vars.head(n_var_to_select).index.tolist()
        
        print(f"   Selected {len(var_genes)} high-variance genes")
        
        selected_genes = de_genes + var_genes
        print(f"\n✅ Total selected: {len(selected_genes)} genes")
        print(f"   - DE genes: {len(de_genes)}")
        print(f"   - Variance genes: {len(var_genes)}")
        
        self.expr = self.expr.loc[selected_genes]
        
        self.expr = self.expr.T
        self.expr = self.expr.fillna(self.expr.mean())
        
        inf_mask = np.isinf(self.expr.values)
        if inf_mask.any():
            print(f"\n   Replacing {inf_mask.sum()} infinite values")
            self.expr = self.expr.replace([np.inf, -np.inf], 0)
        
        print(f"\n✅ Final data shape: {self.expr.shape}")
    
    def prepare_train_test(self, test_size=0.2, random_state=42):
        print(f"\n📊 TRAIN/TEST SPLIT")
        print("-"*80)
        
        X = self.expr.values
        y = self.metadata['diabetes_status'].values
        
        self.label_encoder = LabelEncoder()
        y_encoded = self.label_encoder.fit_transform(y)
        
        print(f"Classes: {self.label_encoder.classes_}")
        
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y_encoded, 
            test_size=test_size, 
            random_state=random_state,
            stratify=y_encoded
        )
        
        print(f"\nTrain set: {self.X_train.shape[0]} samples")
        train_dist = pd.Series(self.y_train).value_counts()
        for idx, count in train_dist.items():
            print(f"   {self.label_encoder.classes_[idx]}: {count}")
        
        print(f"\nTest set: {self.X_test.shape[0]} samples")
        test_dist = pd.Series(self.y_test).value_counts()
        for idx, count in test_dist.items():
            print(f"   {self.label_encoder.classes_[idx]}: {count}")
        
        scaler = StandardScaler()
        self.X_train = scaler.fit_transform(self.X_train)
        self.X_test = scaler.transform(self.X_test)
        
        print(f"\n✅ Data normalized (StandardScaler)")
    
    def train_random_forest(self, n_estimators=100, max_depth=10):
        print(f"\n🌲 TRAINING RANDOM FOREST")
        print("-"*80)
        
        self.rf_model = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            random_state=42,
            class_weight='balanced',
            n_jobs=-1
        )
        
        self.rf_model.fit(self.X_train, self.y_train)
        
        train_score = self.rf_model.score(self.X_train, self.y_train)
        test_score = self.rf_model.score(self.X_test, self.y_test)
        
        print(f"✅ Training complete")
        print(f"   Train accuracy: {train_score:.3f}")
        print(f"   Test accuracy: {test_score:.3f}")
        
        cv_scores = cross_val_score(
            self.rf_model, self.X_train, self.y_train,
            cv=5, scoring='accuracy'
        )
        print(f"   5-fold CV accuracy: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")
        
        return self.rf_model
    
    def train_xgboost(self, n_estimators=100, max_depth=6):
        print(f"\n🚀 TRAINING XGBOOST")
        print("-"*80)
        
        self.xgb_model = xgb.XGBClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=0.1,
            random_state=42,
            use_label_encoder=False,
            eval_metric='mlogloss',
            n_jobs=-1
        )
        
        self.xgb_model.fit(self.X_train, self.y_train)
        
        train_score = self.xgb_model.score(self.X_train, self.y_train)
        test_score = self.xgb_model.score(self.X_test, self.y_test)
        
        print(f"✅ Training complete")
        print(f"   Train accuracy: {train_score:.3f}")
        print(f"   Test accuracy: {test_score:.3f}")
        
        cv_scores = cross_val_score(
            self.xgb_model, self.X_train, self.y_train,
            cv=5, scoring='accuracy'
        )
        print(f"   5-fold CV accuracy: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")
        
        return self.xgb_model
    
    def evaluate_model(self, model, model_name):
        print(f"\n📊 EVALUATING {model_name}")
        print("-"*80)
        
        y_pred = model.predict(self.X_test)
        
        print("\nClassification Report:")
        print(classification_report(
            self.y_test, y_pred,
            target_names=self.label_encoder.classes_
        ))
        
        cm = confusion_matrix(self.y_test, y_pred)
        
        plt.figure(figsize=(8, 6))
        sns.heatmap(
            cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=self.label_encoder.classes_,
            yticklabels=self.label_encoder.classes_
        )
        plt.title(f'{model_name} - Confusion Matrix')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.tight_layout()
        plt.savefig(f'{self.output_dir}/{model_name}_confusion_matrix.png', dpi=300)
        plt.close()
        
        print(f"💾 Saved confusion matrix")
        
        if hasattr(model, 'predict_proba'):
            y_pred_proba = model.predict_proba(self.X_test)
            
            if len(self.label_encoder.classes_) == 2:
                auc = roc_auc_score(self.y_test, y_pred_proba[:, 1])
                print(f"\nROC-AUC Score: {auc:.3f}")
            else:
                auc = roc_auc_score(
                    self.y_test, y_pred_proba,
                    multi_class='ovr', average='weighted'
                )
                print(f"\nWeighted ROC-AUC Score: {auc:.3f}")
        
        results = {
            'model': model_name,
            'accuracy': accuracy_score(self.y_test, y_pred),
            'confusion_matrix': cm
        }
        
        return results
    
    def plot_feature_importance(self, model, model_name, top_n=50):
        print(f"\n🧬 FEATURE IMPORTANCE - {model_name}")
        print("-"*80)
        
        if hasattr(model, 'feature_importances_'):
            importances = model.feature_importances_
        else:
            print("   ⚠️  Model doesn't have feature_importances_")
            return
        
        gene_names = self.expr.columns
        
        importance_df = pd.DataFrame({
            'gene': gene_names,
            'importance': importances
        }).sort_values('importance', ascending=False)
        
        importance_df.to_csv(
            f'{self.output_dir}/{model_name}_feature_importance.csv',
            index=False
        )
        
        print(f"💾 Saved feature importance to CSV")
        print(f"\nTop {min(10, top_n)} important genes:")
        for idx, row in importance_df.head(10).iterrows():
            print(f"   {row['gene']}: {row['importance']:.4f}")
        
        top_features = importance_df.head(top_n)
        
        plt.figure(figsize=(10, max(8, top_n * 0.2)))
        plt.barh(range(len(top_features)), top_features['importance'], alpha=0.8)
        plt.yticks(range(len(top_features)), top_features['gene'], fontsize=8)
        plt.xlabel('Importance Score')
        plt.title(f'{model_name} - Top {top_n} Feature Importance')
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.savefig(f'{self.output_dir}/{model_name}_feature_importance.png', dpi=300)
        plt.close()
        
        print(f"💾 Saved feature importance plot")
        
        return importance_df
    
    def compare_models(self, results_list):
        print(f"\n📊 MODEL COMPARISON")
        print("-"*80)
        
        comparison = pd.DataFrame([
            {'Model': r['model'], 'Accuracy': r['accuracy']}
            for r in results_list
        ])
        
        print(comparison.to_string(index=False))
        
        comparison.to_csv(f'{self.output_dir}/model_comparison.csv', index=False)
        
        plt.figure(figsize=(8, 5))
        plt.bar(comparison['Model'], comparison['Accuracy'], alpha=0.7)
        plt.ylabel('Accuracy')
        plt.title('Model Comparison')
        plt.ylim([0, 1])
        for i, v in enumerate(comparison['Accuracy']):
            plt.text(i, v + 0.02, f'{v:.3f}', ha='center')
        plt.tight_layout()
        plt.savefig(f'{self.output_dir}/model_comparison.png', dpi=300)
        plt.close()
        
        print(f"\n💾 Saved comparison plot")
    
    def run_full_pipeline(self, use_de_selection=True):
        print("\n" + "="*80)
        print("🚀 RUNNING FULL PIPELINE")
        print("="*80)
        
        if use_de_selection:
            self.preprocess_data_with_de(n_de_genes=1000, n_var_genes=4000)
        
        self.prepare_train_test(test_size=0.2)
        
        rf_model = self.train_random_forest(n_estimators=100, max_depth=10)
        xgb_model = self.train_xgboost(n_estimators=100, max_depth=6)
        
        rf_results = self.evaluate_model(rf_model, 'RandomForest')
        xgb_results = self.evaluate_model(xgb_model, 'XGBoost')
        
        rf_importance = self.plot_feature_importance(rf_model, 'RandomForest', top_n=50)
        xgb_importance = self.plot_feature_importance(xgb_model, 'XGBoost', top_n=50)
        
        self.compare_models([rf_results, xgb_results])
        
        print("\n" + "="*80)
        print("✅ PIPELINE COMPLETE!")
        print("="*80)
        print(f"\n📁 Results saved in: {self.output_dir}/")
        
        return rf_model, xgb_model, rf_importance, xgb_importance


def load_gse164416_data():
    print("="*80)
    print("📥 LOADING GSE164416 DATA")
    print("="*80)
    
    print("\n🧬 Loading expression data...")
    expr_path_gz = './suppl_data/GSE164416/GSE164416_DP_htseq_counts.txt.gz'
    
    if not os.path.exists(expr_path_gz):
        raise FileNotFoundError(f"Expression file not found: {expr_path_gz}")
    
    with gzip.open(expr_path_gz, 'rt') as f:
        expression_data = pd.read_csv(f, sep='\t', index_col=0)
    
    print(f"✅ Loaded: {expression_data.shape[0]} genes × {expression_data.shape[1]} samples")
    
    print("\n📋 Loading metadata...")
    metadata_path = './outputdata/GSE164416_metadata.csv'
    
    if not os.path.exists(metadata_path):
        raise FileNotFoundError(f"Metadata file not found: {metadata_path}")
    
    metadata = pd.read_csv(metadata_path, index_col=0)
    print(f"✅ Loaded: {metadata.shape[0]} samples")
    
    return expression_data, metadata


if __name__ == '__main__':
    
    expression_data, metadata = load_gse164416_data()
    
    classifier = DiabetesClassifier(expression_data, metadata)
    
    rf_model, xgb_model, rf_importance, xgb_importance = classifier.run_full_pipeline(use_de_selection=True)
    
    print("\n" + "="*80)
    print("🎉 ALL DONE!")
    print("="*80)